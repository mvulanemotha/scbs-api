const express = require("express");
const router = express.Router();
const products = require('../modal/products')

//get loans for a clients

router.get('/loans', async (req, res) => {

    // loans of clients
    products.loans().then((data) => {

        res.json(data.data)

    }).catch((err) => {
        console.log(err)
    })

})

// get all loan chargies
router.get('/chargies', async (req, res) => {

    // get chargies to be filtered
    products.chargies().then((data) => {

        res.json(data.data)
    
    })

})

// calculate pelnaties for a loan 
router.get('/chargepenalties', async (req, res) => {

    products.loans().then((data) => {

        
        let myData = data.data["pageItems"]
        res.json(myData)
       
        //filter(chargies => chargies.Code.includes(el["Code"]))
        //let newData = mydata.filter((penalties) => penalties.)
    
    })

})

// get client loan details
router.get("/clientloan" , (req , res) => {
    
        
    products.loanClientDetails(req.query.loanId).then(data => {
        
        //res.json(data)
        if(data === undefined){
            res.json("NO ACCOUNT FOUND")
        }else{
            res.json(data.data)
        }
        

    }).catch(error => {
        console.log(error)
    })

})






module.exports = router 