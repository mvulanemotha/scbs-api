const express = require("express");
const router = express.Router();
const app = require("../modal/app")
const calculator = require("../modal/calculator")
const sms = require('../modal/sms')
const client = require('../modal/clients')
const products = require('../modal/products')
const loanpreditor = require('../modal/loanpredictor')


//router to get all clients accounts

router.get('/clients_accounts', (req, res) => {

    //client No
    let clientNo = req.query.clientNo

    app.clientAccounts(clientNo).then(data => {

        res.json(data.data)

    }).catch(error => {
        console.log(error)
    })

})


// apply for a loan
router.post('/apply_for_loan', (req, res) => {

    //clientNo, amount, submittedDate, repaymentDate, disbursementDate

    //console.log(req.body)

    //console.log(calculator.myDate(req.body.submittedDate))
    try {

        let clientNo = req.body.clientNo
        let amount = req.body.amount
        let submittedDate = req.body.submittedDate
        let repaymentDate = req.body.repaymentDate
        let disbursementDate = req.body.disbursementDate

        //add date 

        //call function to make loan application
        app.loanApplication(clientNo, amount, calculator.myDate(submittedDate), calculator.myDate(repaymentDate), calculator.myDate(disbursementDate)).then(data => {

            console.log(data)

        }).catch(err => {
            console.log(err)
            //res.sendStatus(503)

        })

    } catch (err) {
        console.log(err)
    }

})


//save clients from a file
router.post('/saveclients', (req, res) => {

    //call function to save clients No and generate random codes


    let data = req.body.data

    data.forEach(el => {
        app.saveCustomers(el["ClientNo"], el["Code"], el["Cell"]).then((data) => {

            console.log(data)

        }).catch(() => {
            res.sendStatus(503)
        })
    });


})


//get client codes and send  sms
router.get('/clientsCodes', (req, res) => {

    // function to get codes
    app.getClientsCodes().then(data => {

        let myData = data;

        myData.forEach(dt => {
            console.log(dt["customerNo"])

            let message = `Dear Valued Customer please use the information to register with SCBS app.`
                + `Temporary Code:` + dt["temporaryCode"]

            sms.sendMessage(dt["contact"], message, res)
        });


        /*
         customerNo: '0912',
        temporaryCode: 'SCBS-818295',
        status: 1,
        contact: '76222186'
        */


        // call function to send sms     
        /*sms.sendMessage(number, message, res).then((data) => {
            
            res.json({ message: "sent" })
        
        })*/

    }).catch((err) => {

        res.sendStatus(err)

    })

})

//register a new application user
router.post('/register', (req, res) => {

    let dataM = req.body
    let tempCode = dataM.temporaryCode

    try {
        //get client number from a customerNo table then include it in customer table

        app.getCustomerNo(tempCode).then(data => {

            var customerNo = ""

            data.forEach(el => {
                customerNo = el["customerNo"]
            })

            //call function to save new client
            app.registerAppUser(dataM.customerName, dataM.customerSurname, dataM.username, dataM.password, dataM.secretQuestion, dataM.temporaryCode, customerNo).then(data => {
                //console.log(data)
                if (data["affectedRows"] === 1) {

                    //call function to update database

                    app.updateStatus(tempCode).then(data => {
                        // res.sendStatus(200)
                        res.json({ message: "saved" })
                    })
                }
                if (data["affectedRows"] === 0) {

                    res.json({ message: "failed" })

                }
            }).catch((err) => {

                console.log(err)
            })
        }).catch((err) => {
            console.log(err)
        })

    } catch (err) {
        console.log(err)
    }
})


//user login
router.post('/appauth', (req, res) => {

    //call function to login user
    app.appUserLogin(req.body.username, req.body.password).then((response) => {

        res.json(response)

    }).catch(() => {

        res.sendStatus(503)

    })

})


//change password
router.post('/changepassword', (req, res) => {

    //call funtion to change password

    app.changePaasword(req.body.username, req.body.newpass, req.body.oldpass).then(data => {

        if (data["affectedRows"] === 1) {

            res.json({ message: "changed" })

        } else {
            res.json({ message: "failed" })
        }
    }).catch((err) => {
        console.log(err)
    })
})

//get client details
router.get('/client', (req, res) => {

    //function to geclient details

    client.getClient(req.query.clientNo).then(data => {

        res.json(data.data)

    }).catch((err) => {
        res.sendStatus(503)

    })

})


// make transfer
router.post('/transfer', (req, res) => {

    //fromAccount , toAccount , amount, date
    let data = req.body

    app.transferMoney(data.fromAccount, data.toAccount, data.amount, calculator.myDate(data.date)).then((data) => {

        console.log(data)

    }).catch((err) => {

        console.log(err)

    })

})

// get a savings account details
router.get('/savingaccountdetails', (req, res) => {

    // get products detail()s
    products.savingsAccount(req.query.accountNo).then(data => {

        res.json(data.data)

    }).catch((err) => {

        console.log(err)

    })


})

// account transfers for a saving account
router.get('/transfers', (req, res) => {

    //get savings tranfers
    app.savingsTranfers().then(data => {

        res.json(data.data)

    }).catch((err) => {
        console.log(err)
    })

})

//get savings transactions  savings
router.get('/transactions', (req, res) => {

    console.log(req.query.accountNo)

    app.getSavingsTransactions(req.query.accountNo).then(data => {

        res.json(data)

        //console.log(data.data)

    }).catch((err) => {
        console.log(err)
    })

})

// all loan details
router.get('/loandetails', (req, res) => {


    try {

        var account = req.query.accountNo
        var accontsCount = 0
        var response = []

        console.log(req.query.loanCount)

        if (req.query.loanCount == 1) {

            // call function to get loan details
            app.loanDetails(req.query.accountNo).then(data => {

                res.json(data.data)

            }).catch((err) => {
                console.log(err)
            })
        }

        if (req.query.loanCount > 1) {

            account.forEach((acc) => {

                // call function to get loan details
                app.loanDetails(acc).then(data => {

                    accontsCount++
                    response.push(data.data)

                    //res.json(data.data)
                    console.log(acc)
                    if (accontsCount === account.length) {
                        res.json(response)
                    }
                }).catch((err) => {
                    console.log(err)
                })
            })
        }

    } catch (err) {
        console.log(err)
    }
})


// loan predictor 
router.post('/loanpredictor', (req, res) => {

    // check flag if its growth or investment
    //investment, periodMonths, rate

    let data = req.body.data

    let tempData = []

    data.forEach((dt) => {

        loan = loanpreditor.loanPredictorIncome(dt["deposit"], dt["months"], dt["interest"] , dt["depositPeriod"])

        tempData.push({

            "accountNo": dt["accountNo"],
            "investment": dt["deposit"],
            "months" : dt["months"] ,
            "estimateLoan": loan.toFixed(2)
        })
    })

    res.json(tempData)

})





module.exports = router