const headers = require("../modal/header")
const dotenv = require('dotenv');
const { default: axios } = require('axios');
dotenv.config();
const db = require('../../db/charge')


// gets loans associated with a client
let loans = async () => {

    try {

        return await axios({

            method: "get",
            url: process.env.url + "loans",
            withCredentials: true,
            crossdomain: true,
            headers: headers.headers()
        })

    } catch (error) {
        console.log(error)
    }

}

// get chargies so as to extract loan chargies  // will be filtred
let chargies = async () => {

    try {

        return await axios({

            method: "get",
            url: process.env.url + "charges",
            withCredentials: true,
            crossdomain: true,
            headers: headers.headers()
        })

    } catch (error) {
        console.log(error)
    }

}

// save loan details in database
//accountNo 

//principal interest overduesincedate daysInArrears totalOverDue 

let loanDetails = async (principal, interest, overduesincedate, daysInArrears, totalOverDue) => {

    try {

        return new Promise((resolve, reject) => {

            let query = "insert into loanpenalties( accountNo , principal , interest , overduesincedate , daysinArrears , totalOverDue ) select ?,?,?,?,?,?"
            db.query(query, [principal, interest, overduesincedate, daysInArrears, totalOverDue], (err, result) => {

                if (err) {
                    return reject(err)
                }
                return resolve(result)
            })


        })

    } catch (error) {
        console.log(error)
    }

}


// get client loan details 
let loanClientDetails = async (loanID) => {

    try {


        return await axios({
            method: "get",
            url: process.env.url + "loans/" + loanID,
            withCredentials: true,
            crossdomain: true,
            headers: headers.headers()
        })

    } catch (error) {
        console.log(error)
    }

}


//get a savings account

let savingsAccount = async (accountNo) => {
    
    try {
    
        return await axios({
            
            method: "get",
            url: process.env.url + "savingsaccounts/" + accountNo,
            withCredentials: true,
            crossdomain: true,
            headers: headers.headers()
        })
    
    } catch (error) {
        console.log(error)
    }

}




module.exports = { loans, chargies, loanClientDetails , savingsAccount }